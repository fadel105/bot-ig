# How to install
support c9/linux/git-bash windows:<br/>

* $ git clone https://github.com/jrxuii/igbotmay.git
* $ cd igbotmay
* $ unzip node_modules.zip
* $ node ig.js

jangan lupa follow @senjatanpawarna
